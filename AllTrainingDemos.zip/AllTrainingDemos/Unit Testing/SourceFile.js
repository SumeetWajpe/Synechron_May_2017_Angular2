// test suites & test cases (JASMINE)

function Add(x,y){
    return x + y;
}


describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });

  it("add two numbers", function() {
    expect(Add(3,5)).toBe(8);
  });
});