import { NgModule }      from '@angular/core';
import {HttpModule} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import { AppComponent }  from './app.component';
import { CourseComponent }  from './course.component';
import { PostsComponent }  from './posts.component';
import { PostDetailsComponent }  from './postdetails.component';

import {CourseDataService} from './course.service';
import {RouterModule,Routes} from '@angular/router';

const routes:Routes = [
  {path:'courses',component:CourseComponent},
  {path:'posts',component:PostsComponent},
  {path:'posts/:id',component:PostDetailsComponent},
  
   {path:'',redirectTo:'/courses',pathMatch:'full'},   
   {path:'**',redirectTo:'/courses',pathMatch:'full'},   
   
]

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,PostsComponent,CourseComponent,PostDetailsComponent ],
  providers:[CourseDataService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
