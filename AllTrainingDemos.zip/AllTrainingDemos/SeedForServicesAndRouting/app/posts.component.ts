import { Component } from '@angular/core';
import {PostsService} from './posts.service';

@Component({
  selector: 'posts',
   template: `
                    <h2> Posts </h2>
                    <div>
                    <ul>
                    <li *ngFor="let p of posts">
                    <a [routerLink]="['/posts',p.id]" routerLinkActive="active"> 
                         {{p.title}}
                      </a>
                      </li>
                    </ul>
                    </div>
                    `,
                    providers:[PostsService]
})
export class PostsComponent  { 
  name = 'Angular';  
 posts:any;
  constructor(private _posts:PostsService){
    
  }
  ngOnInit(){
    this._posts.getAllPosts().subscribe(res => (this.posts = res));
 
  }
  
 }
