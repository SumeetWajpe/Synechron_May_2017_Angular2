"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var course_service_1 = require('./course.service');
var CourseComponent = (function () {
    function CourseComponent(_coursesrvObj) {
        this._coursesrvObj = _coursesrvObj;
        this.courseToBeAdded = "";
        this.courseReceived = "";
    }
    CourseComponent.prototype.AddNewCourse = function () {
        this._coursesrvObj.insertNewCourse(this.courseToBeAdded);
    };
    CourseComponent.prototype.GetCourse = function () {
        this.courseReceived = this._coursesrvObj.getRandomCourse();
    };
    CourseComponent = __decorate([
        core_1.Component({
            selector: 'course',
            template: "\n    <div style=\"width:500px;border:2px solid black;border-radius:5px;padding:20px;margin:20px\">\n            <h1>  Course Component </h1>\n            <input type=\"text\" [(ngModel)]=\"courseToBeAdded\" /> {{courseReceived}} <br/>\n            <input type=\"button\" value=\"Add>>\" class=\"btn btn-sm btn-primary\" (click)=\"AddNewCourse()\" />\n            <input type=\"button\" value=\"Get Course\" class=\"btn btn-sm btn-primary\" (click)=\"GetCourse()\" />\n    </div>\n    \n    " //,       providers:[CourseDataService]
        }), 
        __metadata('design:paramtypes', [course_service_1.CourseDataService])
    ], CourseComponent);
    return CourseComponent;
}());
exports.CourseComponent = CourseComponent;
//# sourceMappingURL=course.component.js.map