import { Component } from '@angular/core';
import {PostsService} from './posts.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'post-detail',
   template: `
    <h1> Posts details </h1>
    <b>Title : {{currentPost.title}}</b><br/>
    <b>Body : {{currentPost.body}}</b>
    
                    `
})
export class PostDetailsComponent  { 
posts:any;
currentPost:any={};
postId:number=0;
  constructor(private _posts:PostsService,
  private _route:ActivatedRoute){
    
  }

   ngOnInit(){
    this._posts.getAllPosts().subscribe(res =>
    { 
        this.posts = res;
        let sub = this._route.params.subscribe(
            param => {
                this.postId = +param['id'];
                this.posts.forEach(
                    (p:any) => { if(p.id == this.postId){
                        this.currentPost = p;
                    } }
                     );
            }
        )
       
    });
    
  }
  
  
 }
