import { Component } from '@angular/core';
import {PostsService} from './posts.service';

@Component({
  selector: 'my-app',
  template: `             
                   <nav>
                          <a routerLink="/courses" class="btn btn-primary" routerLinkActive="active"> Courses</a>
                          <a routerLink="/posts" class="btn btn-primary"  routerLinkActive="active"> Posts</a>
                          <router-outlet></router-outlet>                          
                   </nav>

                    `, 
                    providers:[PostsService]
})
export class AppComponent  { 
  
  
 }
