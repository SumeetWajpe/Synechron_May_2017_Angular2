import {Http} from '@angular/http';
import {Injectable} from '@angular/core';


@Injectable()
export class CourseDataService{
    courses:string[]=['AngularJS','ReactJS','NodeJS']

constructor(private _http:Http){

}

getRandomCourse():string{
        return this.courses[Math.floor(Math.random() * this.courses.length)]
}

getAllCourses():string[]{
        return this.courses;
}

insertNewCourse(newCourse:string){
        this.courses.push(newCourse);
}

}