import {Component} from '@angular/core';
 import {CourseDataService} from './course.service';

@Component({
    selector:'course',
    template:`
    <div style="width:500px;border:2px solid black;border-radius:5px;padding:20px;margin:20px">
            <h1>  Course Component </h1>
            <input type="text" [(ngModel)]="courseToBeAdded" /> {{courseReceived}} <br/>
            <input type="button" value="Add>>" class="btn btn-sm btn-primary" (click)="AddNewCourse()" />
            <input type="button" value="Get Course" class="btn btn-sm btn-primary" (click)="GetCourse()" />
    </div>
    
    `//,       providers:[CourseDataService]
})
export class CourseComponent{
courseToBeAdded:string="";
courseReceived:string="";
constructor(private _coursesrvObj:CourseDataService){
  
  }
AddNewCourse():void{
        this._coursesrvObj.insertNewCourse(this.courseToBeAdded);
}

GetCourse(){
        this.courseReceived = this._coursesrvObj.getRandomCourse();
}
}