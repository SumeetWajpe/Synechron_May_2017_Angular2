import {Component,Input,Output,EventEmitter} from '@angular/core';

@Component({
    selector:'likes',
    template:`      
   <input type="button" class="btn btn-success" value="+" (click)="onIncrement()"/>
   <input type="button" class="btn btn-danger" value="-" (click)="onDecrement()"/>
               {{count}}     
    `
})
export class LikesComponent{
    @Input("counter")   count:number=0;
    @Output() changeLikes:EventEmitter<number> = new EventEmitter<number>();
onIncrement(){
    this.count += 1;
    this.changeLikes.emit(this.count);
}
onDecrement(){
    this.count -= 1;
    this.changeLikes.emit(this.count);    
}
}