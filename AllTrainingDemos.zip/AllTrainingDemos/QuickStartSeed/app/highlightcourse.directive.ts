import {Directive,ElementRef,Input,HostListener} from '@angular/core';

@Directive({
    selector:'[courseHighlight]'   
})
export class HighlightCourse{
    @Input('coursecolor') passedColor:string = "lightyellow";
    constructor(private element:ElementRef){
                element.nativeElement.style.backgroundColor = this.passedColor;
                element.nativeElement.style.border = "2px solid red";
                element.nativeElement.style.borderRadius = "10px";
                element.nativeElement.style.margin = "20px";
                element.nativeElement.style.padding = "20px"; 
    }
@HostListener('mouseenter') onMouseEnter(){
this.element.nativeElement.style.backgroundColor = this.passedColor;
}

@HostListener('mouseleave') onMouseLeave(){
this.element.nativeElement.style.backgroundColor = null;
}

}