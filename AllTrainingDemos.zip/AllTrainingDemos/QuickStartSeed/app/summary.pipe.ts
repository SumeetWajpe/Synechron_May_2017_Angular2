import {PipeTransform,Pipe} from '@angular/core';

@Pipe({name:'summary'})
export class SummaryPipe implements PipeTransform{
    transform(value:string,args:string){

var maxLimit = (args) ? parseInt(args):50;
            if(value){
                return value.substring(0,maxLimit) + '...';
            }
    }
}