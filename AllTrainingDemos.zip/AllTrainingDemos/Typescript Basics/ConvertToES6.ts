let x = 100;

function Test(x:any){
    console.log(x);
}