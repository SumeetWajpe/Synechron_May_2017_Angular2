// class Car{
//     private name:string;
//     speed:number;
//     constructor(theName:string,theSpeed:number){
//         this.name = theName;
//         this.speed = theSpeed;
//     }

//     Accelerate(){
// //console.log(c.name + ' is running at ' + c.speed + ' kmph !');
// console.log(`${this.name}  is running at  ${this.speed}  kmph !`);
//     }
// }

// // let c = new Car('i20',200);
// // c.Accelerate();

// // OR (Shorter way of creating member variables)

// // class Car{
// //     constructor(private name:string,private speed:number){

// //     }
// // }

// // Inheritance

// class Car{
//     name:string;
//     speed:number;
//     constructor(theName:string,theSpeed:number){
//         console.log("Within Car's Constructor ! ");
//         this.name = theName;
//         this.speed = theSpeed;
//     }

//     Accelerate():string{
//         return (`${this.name}  is running at  ${this.speed}  kmph !`);
//     }
// }
// class JamesBondCar extends Car{
//     useNitro:boolean;
//     static canFly:boolean;
//     constructor(theName:string,theSpeed:number,useNitropower:boolean){
//         super(theName,theSpeed);
//         console.log("Within JamesBondCar's Constructor ! ");        
//         this.useNitro = useNitropower;
//     }

//     Accelerate():string{
//         return super.Accelerate() + ` using nitro ? : ${this.useNitro}` ;
//     }
// }

// let jbc = new JamesBondCar("Houston",400,false);
// console.log(jbc.Accelerate());

// interface IPerson{
//     name:string;
//     age:number;
// }

// interface IEmployee extends IPerson{
//     salary:number;
//     CalculateSalary:() => number;
//     }

// class Person implements IPerson{
//     name:string;
//     age:number;
// }
// class Manager extends  Person implements IEmployee  {
//     name:string;
//     age:number;
//     readonly salary:number; // can assign here or in the constructor
//      CalculateSalary():number{
//             return 10000;
//      }
// }


// abstract class Connection{
//     abstract Open():void;
//     abstract Close():void;
//     getConnectionDetails(){
//             console.log('Getting connection details !');
//     }
// }

// class DBConnection extends Connection{
//     Open():void{

//     }
//      Close():void{

//     }
// }

// Generics
// Arrays , Classes , Functions , Interfaces
//let carsArray:string[] = ['i20','i30']


class Person {
    name:string;
    age:number;
}

let carsArray = new Array<string>();
//carsArray[2] = 10;  // Error !

let personArray = new Array<Person>();
personArray[0] = new Person();
//personArray[1] = 10;

function Swap<T>(x:T,y:T){
    let temp:T;
    temp = x;
    x = y;
    y = temp;
    console.log("X : " + x + " Y : " + y)
}

Swap<number>(20,30);
Swap<string>('Hello',' World');

class Point<T,V>{
    x:T;
    y:V;
}

let pointOfNumbers = new Point<number,string>();


class Manager{
    name:string;
}
class ProjectManager extends Manager{

}

class ActingManager{

}
class Company<T extends Manager>{

}

// let companyA = new Company<string>(); // Error !
//let companyA = new Company<ActingManager>(); // Error !

let companyA = new Company<ProjectManager>();

