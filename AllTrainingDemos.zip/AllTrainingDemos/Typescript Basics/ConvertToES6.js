var x = 100;
function Test(x) {
    console.log(x);
}
