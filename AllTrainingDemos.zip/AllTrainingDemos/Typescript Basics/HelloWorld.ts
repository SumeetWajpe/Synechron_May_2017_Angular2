// let x:string = "Hello Typescript !";
// //x = 10;

// // for(var i =0 ;i<5;i++){
// // console.log('The Value of i : ' + i);
// // }

// // console.log('The Value of i outside for : ' + i);

// {
//     let i;
//     {
//         i = 20;
//     }
//     console.log(i);
// }

// // const PI;
// // PI = 3.14;

// let i:number;
// i =10;

// let j;

// function ReturnANumber():number{
//     return 10;
// }

// let retValue:number = ReturnANumber();

// function ReturnOrNotreturn():any{
// return 10;
// }


// let retValue2 = ReturnOrNotreturn();

// enum Designations{
//     Developer,
//     Tester,
//     Architect,
//     NetworkEngineer
// }

// let myDesgn:Designations;
// myDesgn = Designations.Developer;
// console.log(myDesgn); // numeric value
// console.log(Designations[myDesgn]); // The string Value

// let anyVariable; // type inference any
// let anyVar:any;
// anyVar = 10;
// anyVar='Hello !';

// let person:any = {Name:'Sumeet',Age:32,Location:'Pune'}

// Arrays

let weekDays:string[] = ['Mon','Tue','Wed'];

// for(let day in weekDays){
//     console.log(weekDays[day])
// }


for(let day of weekDays){
    console.log(day)
}
enum Category{
    AutoBiography,
    Inspirational,
    Fiction,
    Travel
}

interface IBook{
    title:string;
    author:string;
    price:number;
    available:boolean;
    category:Category;
}

function GetAllBooks():IBook[]{
    let books:IBook[] = [
        {title:'Wings Of Fire',author:'Dr. APJ Kalam',price:700,available:true,category:Category.Inspirational},
        {title:'I am Malala',author:'Malala',price:300,available:true,category:Category.AutoBiography},
        {title:'Playing It My Way',author:'Sachin Tendulkar',price:1000,available:true,category:Category.AutoBiography},
        {title:'Caged Wings',author:'Don Suri',price:400,available:false,category:Category.Travel},
        {title:'Three Mistakes',author:'Chetan Bhagat',price:700,available:true,category:Category.Fiction}
        
    ];
    return books;
}

let allBooks:IBook[] = GetAllBooks();

function GetFavCategory():Category{
    return Category.Inspirational;
}



//function GetBooksByCategory(filterCategory:Category=Category.Inspirational):string[]{
function GetBooksByCategory(filterCategory:Category=GetFavCategory()):string[]{
    
let filteredBooks:string[] = [];

for(let currBook of allBooks){
    if(currBook.category === filterCategory){
        filteredBooks.push(currBook.title);
    }
}
return filteredBooks;
}
let biographyBooks:string[];
//  biographyBooks = GetBooksByCategory(Category.AutoBiography);
//  biographyBooks = GetBooksByCategory();

// for(let book of biographyBooks){
//     console.log(book);
// }

// biographyBooks.forEach(function(book,index){
//     console.log(book);
// });

// OR
// Arrow Functions

//biographyBooks.forEach(book=>console.log(book) );

// Parameters

// 1. Default Parameters (must be at the last)

// function Print(pages:number=0,author:string="Unknown",typeOfPrint:string="Colour"){
//     console.log(pages,author,typeOfPrint);
// }

// Print();

// 2. Optional Parameters
// function Print(pages:number,author:string,typeOfPrint?:string){
//     console.log(pages,author,typeOfPrint);
// }

// 3. Rest Parameters

// function Print(pages:number,...restOfArguments:any[]){
//     console.log(pages);
// }

// Print(200);
// Print(10,'Don Shori','Colour');
// Print(10,'Shon Dhori',34,'Colour','Texas');


var IDGen : (identifier:number,name:string) => string;

function EmpIdGenerator(id:number,name:string):string{
   console.log('Emp Id generator');
    return id + name;
}

IDGen = EmpIdGenerator; // Assignment
IDGen(10,'ABC');

function ProdIDGenerator(id:number,name:string):string{
   console.log('Prod ID Generator');
    return 'prod_' + id + name ;
}

IDGen = ProdIDGenerator;
IDGen(10,'XYZ');

// Function Overloading

function GetTitles(author:string):string[];
function GetTitles(available:boolean,category:Category):string[];
 function GetTitles(bookProp:any,category?:Category):string[]{

let selectedBooks:string[] = [];
if(typeof bookProp == 'string'){
// for -of 
for(let book of allBooks){
    if(book.author == bookProp){
        selectedBooks.push(book.title);
    }
}
}
if(typeof bookProp == 'boolean'){
    for(let book of allBooks){
    if(book.available == bookProp){
        selectedBooks.push(book.title);
    }
}
}
return selectedBooks;
}


// Interfaces

interface Person{
    name:string;
    age:number;
    address?:string;
}

let aPerson:Person = {name:'Sumeet',age:32,address:'HYD'};
