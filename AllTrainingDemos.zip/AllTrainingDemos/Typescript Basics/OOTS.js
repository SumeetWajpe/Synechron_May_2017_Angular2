// class Car{
//     private name:string;
//     speed:number;
//     constructor(theName:string,theSpeed:number){
//         this.name = theName;
//         this.speed = theSpeed;
//     }
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//     Accelerate(){
// //console.log(c.name + ' is running at ' + c.speed + ' kmph !');
// console.log(`${this.name}  is running at  ${this.speed}  kmph !`);
//     }
// }
// // let c = new Car('i20',200);
// // c.Accelerate();
// // OR (Shorter way of creating member variables)
// // class Car{
// //     constructor(private name:string,private speed:number){
// //     }
// // }
// // Inheritance
// class Car{
//     name:string;
//     speed:number;
//     constructor(theName:string,theSpeed:number){
//         console.log("Within Car's Constructor ! ");
//         this.name = theName;
//         this.speed = theSpeed;
//     }
//     Accelerate():string{
//         return (`${this.name}  is running at  ${this.speed}  kmph !`);
//     }
// }
// class JamesBondCar extends Car{
//     useNitro:boolean;
//     static canFly:boolean;
//     constructor(theName:string,theSpeed:number,useNitropower:boolean){
//         super(theName,theSpeed);
//         console.log("Within JamesBondCar's Constructor ! ");        
//         this.useNitro = useNitropower;
//     }
//     Accelerate():string{
//         return super.Accelerate() + ` using nitro ? : ${this.useNitro}` ;
//     }
// }
// let jbc = new JamesBondCar("Houston",400,false);
// console.log(jbc.Accelerate());
// interface IPerson{
//     name:string;
//     age:number;
// }
// interface IEmployee extends IPerson{
//     salary:number;
//     CalculateSalary:() => number;
//     }
// class Person implements IPerson{
//     name:string;
//     age:number;
// }
// class Manager extends  Person implements IEmployee  {
//     name:string;
//     age:number;
//     readonly salary:number; // can assign here or in the constructor
//      CalculateSalary():number{
//             return 10000;
//      }
// }
// abstract class Connection{
//     abstract Open():void;
//     abstract Close():void;
//     getConnectionDetails(){
//             console.log('Getting connection details !');
//     }
// }
// class DBConnection extends Connection{
//     Open():void{
//     }
//      Close():void{
//     }
// }
// Generics
// Arrays , Classes , Functions , Interfaces
//let carsArray:string[] = ['i20','i30']
var Person = (function () {
    function Person() {
    }
    return Person;
}());
var carsArray = new Array();
//carsArray[2] = 10;  // Error !
var personArray = new Array();
personArray[0] = new Person();
//personArray[1] = 10;
function Swap(x, y) {
    var temp;
    temp = x;
    x = y;
    y = temp;
    console.log("X : " + x + " Y : " + y);
}
Swap(20, 30);
Swap('Hello', ' World');
var Point = (function () {
    function Point() {
    }
    return Point;
}());
var pointOfNumbers = new Point();
var Manager = (function () {
    function Manager() {
    }
    return Manager;
}());
var ProjectManager = (function (_super) {
    __extends(ProjectManager, _super);
    function ProjectManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ProjectManager;
}(Manager));
var ActingManager = (function () {
    function ActingManager() {
    }
    return ActingManager;
}());
var Company = (function () {
    function Company() {
    }
    return Company;
}());
// let companyA = new Company<string>(); // Error !
//let companyA = new Company<ActingManager>(); // Error !
var companyA = new Company();
